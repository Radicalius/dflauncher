All files in this "raw" folder and its subfolders are released into the public domain:  to the extent permitted by law, we waive all copyright to them.  We will not pursue a copyright claim even if this waiver is not applicable in a given area.

Please consider attributing yourself or an alias if you distribute your own modifications so that they aren't confused with vanilla DF (it helps us in bug reports).
